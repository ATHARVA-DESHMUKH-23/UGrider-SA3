// SA3 action-library executor, ROS 2 Humble/Jazzy + MoveIt 2.
// Simulation prototype. All robot trajectories are submitted through MoveIt execute().
// No direct FollowJointTrajectory client, checkpoint or task-specific dispatch.
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <future>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <regex>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>
#include <fcntl.h>
#include <sys/file.h>
#include <unistd.h>
#include <yaml-cpp/yaml.h>
#include <ament_index_cpp/get_package_share_directory.hpp>
#include <Eigen/Geometry>
#include <geometry_msgs/msg/pose.hpp>
#include <trajectory_msgs/msg/joint_trajectory.hpp>
#include <trajectory_msgs/msg/joint_trajectory_point.hpp>
#include <rclcpp/rclcpp.hpp>
#include <tf2/LinearMath/Transform.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/robot_state/robot_state.h>
#include <moveit/robot_state/conversions.h>
#include <moveit/robot_trajectory/robot_trajectory.h>
#include <moveit/trajectory_processing/iterative_time_parameterization.h>
#include <moveit_msgs/srv/get_state_validity.hpp>
#include <moveit_msgs/srv/get_planning_scene.hpp>
#include <moveit_msgs/msg/planning_scene_components.hpp>
#include <moveit_msgs/msg/allowed_collision_matrix.hpp>
#include <moveit_msgs/msg/allowed_collision_entry.hpp>
#include <moveit_msgs/msg/planning_scene.hpp>
#include <moveit_msgs/msg/attached_collision_object.hpp>
#include <moveit_msgs/msg/collision_object.hpp>
#include <std_msgs/msg/string.hpp>
#include <condition_variable>

using MGI=moveit::planning_interface::MoveGroupInterface;
using Plan=MGI::Plan;
using JT=trajectory_msgs::msg::JointTrajectory;
using JP=trajectory_msgs::msg::JointTrajectoryPoint;
using namespace std::chrono_literals;

namespace {
std::string str(const YAML::Node& n,const std::string& key,const std::string& d="") {return n&&n[key]?n[key].as<std::string>():d;}
double num(const YAML::Node& n,const std::string& key,double d) {return n&&n[key]?n[key].as<double>():d;}
bool flag(const YAML::Node& n,const std::string& key,bool d=false) {return n&&n[key]?n[key].as<bool>():d;}
YAML::Node need(const YAML::Node& n,const std::string& key) {if(!n||!n[key])throw std::runtime_error("Required YAML field missing: "+key);return n[key];}
std::vector<std::string> strings(const YAML::Node& n) {return n&&n.IsSequence()?n.as<std::vector<std::string>>():std::vector<std::string>{};}
std::array<double,3> v3(const YAML::Node& n) {if(!n)return {0,0,0};if(!n.IsSequence()||n.size()!=3)throw std::runtime_error("Expected XYZ/RPY list of 3");return {n[0].as<double>(),n[1].as<double>(),n[2].as<double>()};}
void checkScale(double d) {if(!std::isfinite(d)||d<=0||d>1)throw std::runtime_error("Velocity/acceleration scale must be in (0,1]");}
YAML::Node lookup(const YAML::Node& p, const std::string& dotted) {
  if (dotted.empty()) throw std::runtime_error("Empty action parameter name");
  const auto dot = dotted.find('.');
  const auto key = dotted.substr(0, dot);
  if (!p || !p.IsMap() || !p[key])
    throw std::runtime_error("Missing action parameter: " + dotted);
  const YAML::Node child = p[key];
  if (dot == std::string::npos) return child;
  return lookup(child, dotted.substr(dot + 1));
}
YAML::Node interpolate(const YAML::Node& src,const YAML::Node& params) {
  if(!src)return YAML::Node();
  if(src.IsMap()) {YAML::Node out(YAML::NodeType::Map);for(const auto& kv:src)out[kv.first.as<std::string>()]=interpolate(kv.second,params);return out;}
  if(src.IsSequence()) {YAML::Node out(YAML::NodeType::Sequence);for(const auto& n:src)out.push_back(interpolate(n,params));return out;}
  if(!src.IsScalar())return YAML::Clone(src);
  const std::string value=src.Scalar();
  static const std::regex re(R"(\{\{\s*([A-Za-z_][A-Za-z0-9_.]*)\s*\}\})");
  std::smatch match;
  if(std::regex_match(value,match,re))return YAML::Clone(lookup(params,match[1].str()));
  std::string result;auto from=value.cbegin();
  while(std::regex_search(from,value.cend(),match,re)) {
    result.append(from,match[0].first);auto x=lookup(params,match[1].str());
    if(!x.IsScalar())throw std::runtime_error("Interpolated string requires scalar: "+match[1].str());
    result+=x.as<std::string>();from=match[0].second;
  }
  result.append(from,value.cend());return YAML::Node(result);
}
inline double sec(const JP& p) {return rclcpp::Duration(p.time_from_start).seconds();}
inline void setSec(JP& p,double s) {rclcpp::Duration t= rclcpp::Duration::from_seconds(s);const auto ns = static_cast<int64_t>(std::llround(s * 1e9));
    p.time_from_start.sec = static_cast<int32_t>(ns / 1000000000LL);
    p.time_from_start.nanosec =
        static_cast<uint32_t>(ns % 1000000000LL);}
JP interpolateJT(const JT& t,double seconds,double stretch) {
  const double u=seconds/stretch;size_t hi=0;
  while(hi+1<t.points.size()&&sec(t.points[hi])<u)++hi;
  size_t lo=hi?hi-1:hi;if(u>=sec(t.points.back()))lo=hi=t.points.size()-1;
  auto &a=t.points[lo],&b=t.points[hi];const double d=sec(b)-sec(a),alpha=d>1e-9?std::clamp((u-sec(a))/d,0.,1.):0.;
  JP r;
  for(size_t i=0;i<t.joint_names.size();++i) {
    r.positions.push_back(a.positions.at(i)+(b.positions.at(i)-a.positions.at(i))*alpha);
    if(a.velocities.size()==t.joint_names.size()&&b.velocities.size()==t.joint_names.size())r.velocities.push_back((a.velocities[i]+(b.velocities[i]-a.velocities[i])*alpha)/stretch);
    if(a.accelerations.size()==t.joint_names.size()&&b.accelerations.size()==t.joint_names.size())r.accelerations.push_back((a.accelerations[i]+(b.accelerations[i]-a.accelerations[i])*alpha)/(stretch*stretch));
  }return r;
}
JT mergeTracks(const std::vector<JT>& tracks) {
  if(tracks.empty())throw std::runtime_error("No planned tracks");
  if(tracks.size()==1)return tracks[0];
  std::set<std::string> jointNames;double total=0;
  for(const auto& t:tracks){if(t.joint_names.empty()||t.points.empty()||sec(t.points.back())<=0)throw std::runtime_error("Invalid planned track");
    for(auto& j:t.joint_names)if(!jointNames.insert(j).second)throw std::runtime_error("Overlapping joint: "+j);
    total=std::max(total,sec(t.points.back()));}
  std::vector<double> times{0,total};
  for(const auto& t:tracks){auto scale=total/sec(t.points.back());for(const auto& p:t.points)times.push_back(sec(p)*scale);}
  std::sort(times.begin(),times.end());times.erase(std::unique(times.begin(),times.end(),[](double x,double y){return std::abs(x-y)<1e-8;}),times.end());
  JT out;for(const auto& t:tracks)out.joint_names.insert(out.joint_names.end(),t.joint_names.begin(),t.joint_names.end());
  for(double time:times){JP p;setSec(p,time);bool allV=true,allA=true;std::vector<JP> parts;
    for(const auto& t:tracks){auto x=interpolateJT(t,time,total/sec(t.points.back()));parts.push_back(x);allV&=x.velocities.size()==t.joint_names.size();allA&=x.accelerations.size()==t.joint_names.size();}
    for(auto& x:parts){p.positions.insert(p.positions.end(),x.positions.begin(),x.positions.end());if(allV)p.velocities.insert(p.velocities.end(),x.velocities.begin(),x.velocities.end());if(allA)p.accelerations.insert(p.accelerations.end(),x.accelerations.begin(),x.accelerations.end());}
    out.points.push_back(std::move(p));}
  return out;
}
JT holdTrack(const moveit::core::RobotState& state,const moveit::core::JointModelGroup* jm,double duration) {
  if(!jm)throw std::runtime_error("Missing robot group for stationary hold");
  JT out;out.joint_names=jm->getVariableNames();if(out.joint_names.empty())throw std::runtime_error("Hold has no joints");
  JP p;for(const auto& j:out.joint_names)p.positions.push_back(state.getVariablePosition(j));
  p.velocities.assign(p.positions.size(),0);p.accelerations.assign(p.positions.size(),0);
  setSec(p,0);out.points.push_back(p);setSec(p,std::max(0.05,duration));out.points.push_back(p);return out;
}
tf2::Transform asTF(const geometry_msgs::msg::Pose& p) {return tf2::Transform(tf2::Quaternion(p.orientation.x,p.orientation.y,p.orientation.z,p.orientation.w),tf2::Vector3(p.position.x,p.position.y,p.position.z));}
geometry_msgs::msg::Pose asPose(const tf2::Transform& t) {geometry_msgs::msg::Pose p;auto q=t.getRotation();q.normalize();p.position.x=t.getOrigin().x();p.position.y=t.getOrigin().y();p.position.z=t.getOrigin().z();p.orientation.x=q.x();p.orientation.y=q.y();p.orientation.z=q.z();p.orientation.w=q.w();return p;}
struct Goal{std::string robot,link,state;geometry_msgs::msg::Pose pose;};
struct Lock {int fd{-1};explicit Lock(const std::string& path){fd=::open(path.c_str(),O_CREAT|O_RDWR,0666);if(fd<0||flock(fd,LOCK_EX))throw std::runtime_error("Cannot obtain ACM lock: "+path);}~Lock(){if(fd>=0){flock(fd,LOCK_UN);::close(fd);}}};
}

class ActionEngine {
public:
  explicit ActionEngine(rclcpp::Node::SharedPtr node):n_(std::move(node)),tf_(n_->get_clock()) {
    tf_.setUsingDedicatedThread(true);listener_=std::make_shared<tf2_ros::TransformListener>(tf_,n_,false);
    const auto lib=n_->declare_parameter<std::string>("action_library_path","");
    name_=n_->declare_parameter<std::string>("action_name","");
    instance_=n_->declare_parameter<std::string>("instance_id","manual");
    dry_=n_->declare_parameter<bool>("dry_run",true);
    sim_=n_->declare_parameter<bool>("simulation_confirmed",false);
    if(lib.empty()||name_.empty())throw std::runtime_error("action_library_path and action_name required");
    YAML::Node root=YAML::LoadFile(lib);YAML::Node library=need(root,"action_library");
    fullGroup_=str(library,"collision_group","sa3_all_robots");
    acmLock_=str(library,"acm_lock","/tmp/sa3_action_engine_acm.lock");
    auto libraryActions=need(library,"actions");if(!libraryActions[name_])throw std::runtime_error("Unknown action: "+name_);
    auto act=libraryActions[name_];
    YAML::Node defaults=act["defaults"]?YAML::Clone(act["defaults"]):YAML::Node(YAML::NodeType::Map);
    auto arguments=YAML::Load(n_->declare_parameter<std::string>("action_inputs_yaml","{}"));
    if(arguments&&arguments.IsMap())for(const auto& item:arguments)defaults[item.first.as<std::string>()]=item.second;
    params_=defaults;action_=interpolate(act,params_);
    const auto wcPackage=str(library,"workcell_package","sa2_description");
    const auto wcFile=str(library,"workcell_file","config/workcell.yaml");
    // This path may be supplied explicitly to inspect the user's live workcell.
    auto wcPath=n_->declare_parameter<std::string>("workcell_config_path","");
    if(wcPath.empty())wcPath=(std::filesystem::path(ament_index_cpp::get_package_share_directory(wcPackage))/wcFile).string();
    auto wcRoot=YAML::LoadFile(wcPath);workcell_=need(wcRoot,"workcell");
    for(const auto& item:need(workcell_,"robots")) {
      const auto robot=item.first.as<std::string>();auto config=item.second;
      robotGroup_[robot]=str(config,"group");
      robotLink_[robot]=str(config,"planning_link",str(config,"link"));
      robotTyingLink_[robot]=str(config,"tying_link",robotLink_[robot]);
      robotToolMount_[robot]=str(config,"tool_mount_link",robot+"_tool_mount");
    }
    validity_=n_->create_client<moveit_msgs::srv::GetStateValidity>("/check_state_validity");
    getScene_=n_->create_client<moveit_msgs::srv::GetPlanningScene>("/get_planning_scene");
    // Standard topic bridge. Only the gantry node touches its FollowJointTrajectory action.
    gantryCmd_=n_->create_publisher<std_msgs::msg::String>("/sa3/gantry/command",rclcpp::QoS(20).reliable());
    gantryCancel_=n_->create_publisher<std_msgs::msg::String>("/sa3/gantry/cancel",rclcpp::QoS(20).reliable());
    gantryStatus_=n_->create_subscription<std_msgs::msg::String>("/sa3/gantry/status",
      rclcpp::QoS(rclcpp::KeepLast(100)).reliable().transient_local(),
      [this](const std_msgs::msg::String::SharedPtr msg) {
        try {
          const auto status=YAML::Load(msg->data);
          const auto id=str(status,"request_id");
          if(id.empty())return;
          {
            std::lock_guard<std::mutex> lock(gantryMutex_);
            gantryResults_[id]={str(status,"status"),str(status,"message")};
          }
          gantryCv_.notify_all();
        } catch(const std::exception& e) {
          RCLCPP_WARN(n_->get_logger(),"[GANTRY] malformed status message: %s",e.what());
        }
      });
  }
  int run(){
    try {
      if(!dry_&&!sim_)throw std::runtime_error("Execution restricted to explicitly confirmed simulation");
      auto steps=need(action_,"steps");if(!steps.IsSequence())throw std::runtime_error("Action steps must be a list");
      for(const auto& step:steps)stepRun(step);
      restoreOutstanding();
      RCLCPP_INFO(n_->get_logger(),"[SA3 ACTION] SUCCESS %s",name_.c_str());return 0;
    }catch(const std::exception& e){
      RCLCPP_ERROR(n_->get_logger(),"[SA3 ACTION] FAILED %s: %s",name_.c_str(),e.what());
      // Cancel any outstanding gantry FJT command on failure (cannot guarantee hard stop).
      cancelPendingGantry();
      try{restoreOutstanding();}catch(const std::exception& x){RCLCPP_ERROR(n_->get_logger(),"ACM RESTORE FAILED: %s",x.what());}
      return 1;
    }
  }
private:
  MGI& group(const std::string& name){if(name.empty())throw std::runtime_error("Empty SRDF group");auto& ptr=groups_[name];if(!ptr)ptr=std::make_unique<MGI>(n_,name);return *ptr;}
  geometry_msgs::msg::Pose tfPose(const std::string& frame){
    if(frame.empty())throw std::runtime_error("Empty target reference frame");
    auto t=tf_.lookupTransform("world",frame,tf2::TimePointZero,tf2::durationFromSec(10));
    geometry_msgs::msg::Pose p;p.position.x=t.transform.translation.x;p.position.y=t.transform.translation.y;p.position.z=t.transform.translation.z;p.orientation=t.transform.rotation;return p;
  }
  Goal goalOf(const YAML::Node& n) {
    Goal g;g.robot=str(n,"robot");if(!robotGroup_.count(g.robot))throw std::runtime_error("Robot missing from workcell: "+g.robot);
    g.link=str(n,"link",robotLink_.at(g.robot));
    if(g.link=="@tying")g.link=robotTyingLink_.at(g.robot);
    else if(g.link=="@tool")g.link=robotToolMount_.at(g.robot);
    g.state=str(n,"named_state");
    if(!g.state.empty())return g;
    auto target=need(n,"target");g.pose=tfPose(str(target,"reference"));
    auto offset=v3(target["xyz"]),rpy=v3(target["rpy"]);
    const auto offsetFrame=str(target,"offset_frame","world"),rpyFrame=str(target,"rpy_frame","local");
    tf2::Quaternion q(g.pose.orientation.x,g.pose.orientation.y,g.pose.orientation.z,g.pose.orientation.w);q.normalize();
    // Reproduce the working flange_pp pick-frame behavior: apply the original
    // pick XYZ offset first (using the raw TF orientation), then the step's
    // world-frame retract offset, and finally the pick RPY orientation.
    if(target["base_xyz"]) {
      const auto base=v3(target["base_xyz"]);
      const auto baseFrame=str(target,"base_offset_frame","local");
      tf2::Vector3 baseShift(base[0],base[1],base[2]);
      if(baseFrame=="local")baseShift=tf2::quatRotate(q,baseShift);
      else if(baseFrame!="world")throw std::runtime_error("Unsupported base_offset_frame: "+baseFrame);
      g.pose.position.x+=baseShift.x();g.pose.position.y+=baseShift.y();g.pose.position.z+=baseShift.z();
    }
    tf2::Vector3 shift(offset[0],offset[1],offset[2]);
    if(offsetFrame=="local")shift=tf2::quatRotate(q,shift);
    else if(offsetFrame!="world")throw std::runtime_error("Unsupported offset_frame: "+offsetFrame);
    g.pose.position.x+=shift.x();g.pose.position.y+=shift.y();g.pose.position.z+=shift.z();
    tf2::Quaternion dq;dq.setRPY(rpy[0],rpy[1],rpy[2]);
    if(rpyFrame=="local")q=q*dq;else if(rpyFrame=="world")q=dq*q;
    else throw std::runtime_error("Unsupported rpy_frame: "+rpyFrame);
    q.normalize();g.pose.orientation.x=q.x();g.pose.orientation.y=q.y();g.pose.orientation.z=q.z();g.pose.orientation.w=q.w();return g;
  }
  void configure(MGI& mg,const std::string& motion,const YAML::Node& cfg) {
    mg.clearPoseTargets();mg.clearPathConstraints();mg.setPoseReferenceFrame("world");
    const auto planning=action_["planning"];
    const auto pipeline=(motion=="moveL"||motion=="movePTP")?"pilz_industrial_motion_planner":"ompl";
    mg.setPlanningPipelineId(pipeline);
    mg.setPlannerId(motion=="moveL"?"LIN":motion=="movePTP"?"PTP":"RRTConnectkConfigDefault");
    const double vel=num(cfg,"velocity",num(planning,motion=="moveL"?"linear_velocity":"joint_velocity",0.35));
    const double acc=num(cfg,"acceleration",num(planning,"acceleration",0.35));checkScale(vel);checkScale(acc);
    mg.setPlanningTime(num(cfg,"planning_time",num(planning,"planning_time",15)));
    mg.setNumPlanningAttempts(static_cast<int>(num(planning,"planning_attempts",10)));
    mg.setMaxVelocityScalingFactor(vel);mg.setMaxAccelerationScalingFactor(acc);
  }
  Plan separate(const Goal& g,const std::string& motion,const YAML::Node& cfg,const moveit_msgs::msg::RobotState& start){
    auto& mg=group(robotGroup_.at(g.robot));configure(mg,motion,cfg);mg.setStartState(start);
    if(!g.state.empty()) {
      if(motion!="moveJ")throw std::runtime_error("Named target requires moveJ");
      if(!mg.setNamedTarget(g.state))throw std::runtime_error("Unknown named state: "+g.state);
    }else if(!mg.setPoseTarget(g.pose,g.link))throw std::runtime_error("Pose goal rejected: "+g.robot);
    Plan plan;auto status=mg.plan(plan);mg.clearPoseTargets();
    if(status!=moveit::core::MoveItErrorCode::SUCCESS)
      throw std::runtime_error("Individual planning failed for "+g.robot+" code="+std::to_string(status.val));
    return plan;
  }
  Plan combined(const std::vector<Goal>& goals,const std::string& combinedGroup,const YAML::Node& cfg) {
    auto& mg=group(combinedGroup);configure(mg,"moveJ",cfg);auto current=mg.getCurrentState(10);
    if(!current)throw std::runtime_error("Cannot get live state for combined plan");
    auto target=std::make_shared<moveit::core::RobotState>(*current);
    for(const auto& g:goals){const auto jm=target->getJointModelGroup(robotGroup_.at(g.robot));
      if(!jm)throw std::runtime_error("Robot group missing: "+g.robot);
      if(!g.state.empty()){if(!target->setToDefaultValues(jm,g.state))throw std::runtime_error("Unknown named state "+g.state);}
      else if(!target->setFromIK(jm,g.pose,g.link,num(cfg,"ik_timeout",1.0)))throw std::runtime_error("IK failed for "+g.robot);}
    mg.setStartStateToCurrentState();
    if(!mg.setJointValueTarget(*target))throw std::runtime_error("Combined goal rejected");
    Plan plan;auto code=mg.plan(plan);
    if(code!=moveit::core::MoveItErrorCode::SUCCESS)throw std::runtime_error("Combined planning failed code="+std::to_string(code.val));
    return plan;
  }
  Plan merged(const std::vector<Goal>& goals,const std::vector<std::string>& participants,
              const std::string& combinedGroup,const std::string& motion,const YAML::Node& cfg) {
    auto& mg=group(combinedGroup);auto current=mg.getCurrentState(10);
    if(!current)throw std::runtime_error("No current state for merged planning");
    moveit_msgs::msg::RobotState start;moveit::core::robotStateToRobotStateMsg(*current,start);
    std::set<std::string> active;std::vector<JT> tracks;
    for(const auto& g:goals) {
      if(!active.insert(g.robot).second)throw std::runtime_error("Duplicate goal robot: "+g.robot);
      tracks.push_back(separate(g,motion,cfg,start).trajectory_.joint_trajectory);
    }
    double duration=0;for(const auto& t:tracks)if(!t.points.empty())duration=std::max(duration,sec(t.points.back()));
    if(duration<=0)throw std::runtime_error("No executable track duration");
    // Stationary participant arms are represented explicitly in the combined trajectory.
    for(const auto& robot:participants)if(!active.count(robot)){
      if(!robotGroup_.count(robot))throw std::runtime_error("Unknown participant: "+robot);
      tracks.push_back(holdTrack(*current,current->getJointModelGroup(robotGroup_.at(robot)),duration));
    }
    Plan result;result.start_state_=start;result.trajectory_.joint_trajectory=mergeTracks(tracks);
    const auto jmg=current->getJointModelGroup(combinedGroup);
    if(!jmg)throw std::runtime_error("Missing combined group: "+combinedGroup);
    std::set<std::string> actual(result.trajectory_.joint_trajectory.joint_names.begin(),result.trajectory_.joint_trajectory.joint_names.end());
    // Reject trajectories that omit joints in the requested execution group.
    for(const auto& joint:jmg->getVariableNames())if(!actual.count(joint))throw std::runtime_error("Combined group joint not covered: "+joint);
    return result;
  }
  Plan coordinatedCartesian(const std::vector<Goal>& goals,const std::string& combinedGroup,const YAML::Node& cfg) {
    auto& mg=group(combinedGroup);auto start=mg.getCurrentState(10);if(!start)throw std::runtime_error("No live state for Cartesian");
    robot_trajectory::RobotTrajectory rt(mg.getRobotModel(),combinedGroup);rt.addSuffixWayPoint(*start,0);
    auto working=std::make_shared<moveit::core::RobotState>(*start);
    int n=1;std::vector<Eigen::Isometry3d> from;
    for(const auto& g:goals){if(!g.state.empty())throw std::runtime_error("Cartesian named state unsupported");
      auto begin=start->getGlobalLinkTransform(g.link);from.push_back(begin);
      Eigen::Vector3d target(g.pose.position.x,g.pose.position.y,g.pose.position.z);
      Eigen::Quaterniond q0(begin.rotation()),q1(g.pose.orientation.w,g.pose.orientation.x,g.pose.orientation.y,g.pose.orientation.z);
      n=std::max(n,static_cast<int>(std::ceil(std::max((target-begin.translation()).norm()/0.01,q0.angularDistance(q1)/0.025))));}
    if(n>2000)throw std::runtime_error("Cartesian segment requires too many samples");
    for(int k=1;k<=n;++k){double a=double(k)/n;
      for(size_t i=0;i<goals.size();++i){const auto& g=goals[i];const auto& startT=from[i];
        Eigen::Vector3d dest(g.pose.position.x,g.pose.position.y,g.pose.position.z),pos=startT.translation()*(1-a)+dest*a;
        Eigen::Quaterniond q0(startT.rotation()),q1(g.pose.orientation.w,g.pose.orientation.x,g.pose.orientation.y,g.pose.orientation.z);
        auto q=q0.slerp(a,q1).normalized();
        geometry_msgs::msg::Pose p=g.pose;p.position.x=pos.x();p.position.y=pos.y();p.position.z=pos.z();p.orientation.w=q.w();p.orientation.x=q.x();p.orientation.y=q.y();p.orientation.z=q.z();
        const auto jm=working->getJointModelGroup(robotGroup_.at(g.robot));
        if(!jm||!working->setFromIK(jm,p,g.link,num(cfg,"ik_timeout",1.0)))throw std::runtime_error("Cartesian IK failed for "+g.robot+" sample="+std::to_string(k));
      }working->update();rt.addSuffixWayPoint(*working,0);}
    trajectory_processing::IterativeParabolicTimeParameterization parameterizer;
    double vel=num(cfg,"velocity",num(action_["planning"],"linear_velocity",0.3));
    double acc=num(cfg,"acceleration",num(action_["planning"],"acceleration",0.3));checkScale(vel);checkScale(acc);
    if(!parameterizer.computeTimeStamps(rt,vel,acc))throw std::runtime_error("Cartesian timestamp generation failed");
    Plan result;moveit::core::robotStateToRobotStateMsg(*start,result.start_state_);rt.getRobotTrajectoryMsg(result.trajectory_);return result;
  }
  void validate(const Plan& plan) {
    if(dry_)return; // Dry run is static configuration preflight, not a simulated trajectory approval.
    if(!validity_->wait_for_service(10s))throw std::runtime_error("/check_state_validity not available");
    const auto& tr=plan.trajectory_.joint_trajectory;if(tr.points.empty()||tr.joint_names.empty())throw std::runtime_error("Empty trajectory");
    size_t counter=0;
    auto inspect=[&](const std::vector<double>& q) {
      if(++counter>5000)throw std::runtime_error("Collision sample limit exceeded");
      auto req=std::make_shared<moveit_msgs::srv::GetStateValidity::Request>();req->group_name=fullGroup_;
      req->robot_state=plan.start_state_;req->robot_state.is_diff=true;req->robot_state.attached_collision_objects.clear();
      auto& js=req->robot_state.joint_state;
      for(size_t i=0;i<tr.joint_names.size();++i){auto it=std::find(js.name.begin(),js.name.end(),tr.joint_names[i]);
        if(it==js.name.end()||static_cast<size_t>(it-js.name.begin())>=js.position.size())throw std::runtime_error("Joint missing from full state: "+tr.joint_names[i]);
        js.position[it-js.name.begin()]=q.at(i);}
      auto future=validity_->async_send_request(req);
      if(future.wait_for(20s)!=std::future_status::ready){validity_->remove_pending_request(future);throw std::runtime_error("State validity timeout");}
      const auto result=future.get();
      if(!result->valid){for(const auto& c:result->contacts)RCLCPP_ERROR(n_->get_logger(),"COLLISION sample=%zu %s <-> %s",counter,c.contact_body_1.c_str(),c.contact_body_2.c_str());throw std::runtime_error("Full-cell collision validation rejected at sample="+std::to_string(counter));}
    };
    inspect(tr.points.front().positions);
    for(size_t i=1;i<tr.points.size();++i){const auto& a=tr.points[i-1].positions,&b=tr.points[i].positions;
      if(a.size()!=b.size())throw std::runtime_error("Malformed trajectory point");
      double maxStep=0;for(size_t j=0;j<a.size();++j)maxStep=std::max(maxStep,std::abs(b[j]-a[j]));
      const int pieces=std::max(1,static_cast<int>(std::ceil(maxStep/0.025)));
      for(int k=1;k<=pieces;++k){double alpha=double(k)/pieces;std::vector<double> q;
        for(size_t j=0;j<a.size();++j)q.push_back(a[j]+alpha*(b[j]-a[j]));inspect(q);}}
    RCLCPP_INFO(n_->get_logger(),"[FULL VALIDATION] %zu samples passed",counter);
  }
  void verifyStart(const Plan& p,const std::string& combinedGroup) {
    auto live=group(combinedGroup).getCurrentState(10);if(!live)throw std::runtime_error("No live state before execute");
    const auto& t=p.trajectory_.joint_trajectory;
    if(t.points.empty())throw std::runtime_error("Empty plan");
    for(size_t i=0;i<t.joint_names.size();++i){double difference=std::abs(live->getVariablePosition(t.joint_names[i])-t.points.front().positions.at(i));
      if(difference>0.05)throw std::runtime_error("Robot moved during planning (stale start): "+t.joint_names[i]);}
  }
  void motion(const YAML::Node& step) {
    auto op=need(step,"goals");std::vector<Goal> goals;std::set<std::string> seen;
    for(const auto& item:op){auto g=goalOf(item);if(!seen.insert(g.robot).second)throw std::runtime_error("Duplicate active robot in step");goals.push_back(g);}
    if(goals.empty())throw std::runtime_error("Motion step has no goals");
    const auto combinedGroup=str(step,"group");const auto motion=str(step,"motion","moveJ");const auto strategy=str(step,"strategy","separate_merge");
    // Planning fallback candidates are entirely declarative and BEFORE execution.
    // Execution results are never retried or replayed.
    std::vector<std::pair<std::string,std::string>> candidates{{motion,strategy}};
    if(step["fallbacks"])for(const auto& candidate:step["fallbacks"])
      candidates.emplace_back(str(candidate,"motion",motion),str(candidate,"strategy",strategy));
    Plan plan;bool found=false;std::string reason;
    for(const auto& candidate:candidates){
      const auto& mode=candidate.first;const auto& path=candidate.second;
      try {
        if(path=="separate_merge"){
          if(mode!="moveJ"&&mode!="moveL"&&mode!="movePTP")throw std::runtime_error("Unknown separate planner: "+mode);
          const auto participants=strings(need(step,"participants"));
          plan=merged(goals,participants,combinedGroup,mode,step);
        }else if(path=="combined"){
          if(mode!="moveJ")throw std::runtime_error("Combined planning supports moveJ here");
          plan=combined(goals,combinedGroup,step);
        }else if(path=="coordinated_cartesian"){
          if(mode!="moveL")throw std::runtime_error("Coordinated Cartesian supports moveL here");
          plan=coordinatedCartesian(goals,combinedGroup,step);
        }else throw std::runtime_error("Unsupported planning strategy: "+path);
        if(!dry_){validate(plan);verifyStart(plan,combinedGroup);}
        found=true;break;
      }catch(const std::exception& e){
        reason=e.what();
        RCLCPP_WARN(n_->get_logger(),"[PRE-EXEC PLANNING FALLBACK] step=%s mode=%s strategy=%s failed: %s",
          str(step,"id").c_str(),mode.c_str(),path.c_str(),reason.c_str());
      }
    }
    if(!found)throw std::runtime_error("All pre-execution planning candidates failed: "+reason);
    if(dry_){RCLCPP_INFO(n_->get_logger(),"[DRY] parsed step=%s strategy=%s",str(step,"id").c_str(),strategy.c_str());return;}
    // Only MoveIt executes robot motion. It dispatches to configured controllers internally.
    const auto code=group(combinedGroup).execute(plan);
    if(code!=moveit::core::MoveItErrorCode::SUCCESS)throw std::runtime_error("MoveIt execution uncertain/failed code="+std::to_string(code.val));
  }
  // The scene/ACM operations below remain owned by the action engine, not the gantry node.
  void attachObject(const YAML::Node& step){
    const auto id=str(step,"object"),link=str(step,"link"),dock=str(step,"dock_frame");
    if(id.empty()||link.empty())throw std::runtime_error("attach requires object and link");
    if(dry_)return;
    auto objects=scene_.getObjects({id});
    if(!objects.count(id)&&flag(step,"optional",false))return;
    if(!objects.count(id))throw std::runtime_error("Attach object absent from world: "+id);
    auto source=objects.at(id);
    if(!source.header.frame_id.empty()&&source.header.frame_id!="world")throw std::runtime_error("Attached object must be world-frame: "+id);
    const auto mode=str(step,"placement_mode","preserve_world");
    if(mode=="preserve_world")source.pose=asPose(asTF(tfPose(link)).inverse()*asTF(source.pose));
    else if(mode=="dock_to_mount") {if(dock.empty())throw std::runtime_error("dock_to_mount needs dock_frame");source.pose=asPose(asTF(tfPose(dock)).inverse()*asTF(source.pose));}
    else throw std::runtime_error("Unknown placement_mode");
    source.header.frame_id=link;source.operation=moveit_msgs::msg::CollisionObject::ADD;
    moveit_msgs::msg::AttachedCollisionObject a;a.link_name=link;a.object=source;a.touch_links=strings(step["touch_links"]);
    auto original=objects.at(id);
    scene_.removeCollisionObjects({id});
    if(!scene_.applyAttachedCollisionObjects({a})) {
      original.operation=moveit_msgs::msg::CollisionObject::ADD;
      scene_.applyCollisionObject(original);
      throw std::runtime_error("Scene attach rejected; attempted world-object rollback: "+id);
    }
    bool stable=false;
    for(int i=0;i<25;++i){auto attached=scene_.getAttachedObjects({id});auto world=scene_.getObjects({id});
      if(attached.count(id)&&!world.count(id)&&attached.at(id).link_name==link){stable=true;break;}std::this_thread::sleep_for(100ms);}
    if(!stable)throw std::runtime_error("Scene attachment not verified: "+id);
  }
  void detachObject(const YAML::Node& step){
    auto id=str(step,"object"),link=str(step,"link");if(dry_)return;
    auto attached=scene_.getAttachedObjects({id});
    if(!attached.count(id)&&flag(step,"optional",false))return;
    if(!attached.count(id))throw std::runtime_error("Cannot detach unowned object: "+id);
    auto obj=attached.at(id);if(!link.empty()&&obj.link_name!=link)throw std::runtime_error("Wrong detach owner: "+id);
    auto world=obj.object;world.pose=asPose(asTF(tfPose(obj.link_name))*asTF(world.pose));
    world.header.frame_id="world";world.operation=moveit_msgs::msg::CollisionObject::ADD;
    moveit_msgs::msg::PlanningScene diff;diff.is_diff=true;diff.robot_state.is_diff=true;
    moveit_msgs::msg::AttachedCollisionObject remove;remove.link_name=obj.link_name;remove.object.id=id;remove.object.operation=moveit_msgs::msg::CollisionObject::REMOVE;
    diff.robot_state.attached_collision_objects.push_back(remove);diff.world.collision_objects.push_back(world);
    if(!scene_.applyPlanningScene(diff))throw std::runtime_error("Scene detach rejected: "+id);
    bool stable=false;for(int i=0;i<25;++i){if(!scene_.getAttachedObjects({id}).count(id)&&scene_.getObjects({id}).count(id)){stable=true;break;}std::this_thread::sleep_for(100ms);}
    if(!stable)throw std::runtime_error("Scene detach not verified: "+id);
  }
  moveit_msgs::msg::AllowedCollisionMatrix getAcm() {
    if(!getScene_->wait_for_service(10s))throw std::runtime_error("/get_planning_scene unavailable");
    auto req=std::make_shared<moveit_msgs::srv::GetPlanningScene::Request>();
    req->components.components=moveit_msgs::msg::PlanningSceneComponents::ALLOWED_COLLISION_MATRIX;
    auto future=getScene_->async_send_request(req);if(future.wait_for(20s)!=std::future_status::ready){getScene_->remove_pending_request(future);throw std::runtime_error("ACM service timed out");}
    return future.get()->scene.allowed_collision_matrix;
  }
  std::optional<bool> pairValue(const moveit_msgs::msg::AllowedCollisionMatrix& acm,const std::string& a,const std::string& b){
    auto x=std::find(acm.entry_names.begin(),acm.entry_names.end(),a),y=std::find(acm.entry_names.begin(),acm.entry_names.end(),b);
    if(x==acm.entry_names.end()||y==acm.entry_names.end())return std::nullopt;
    auto i=x-acm.entry_names.begin(),j=y-acm.entry_names.begin();
    if(static_cast<size_t>(i)>=acm.entry_values.size()||static_cast<size_t>(j)>=acm.entry_values[i].enabled.size())throw std::runtime_error("Malformed ACM");
    return acm.entry_values[i].enabled[j];
  }
  size_t ensureAcmName(moveit_msgs::msg::AllowedCollisionMatrix& acm,const std::string& key){
    auto it=std::find(acm.entry_names.begin(),acm.entry_names.end(),key);if(it!=acm.entry_names.end())return it-acm.entry_names.begin();
    acm.entry_names.push_back(key);for(auto& row:acm.entry_values)row.enabled.push_back(false);
    moveit_msgs::msg::AllowedCollisionEntry x;x.enabled.resize(acm.entry_names.size(),false);acm.entry_values.push_back(x);return acm.entry_names.size()-1;
  }
  // ACM normalization can remove explicit entries for attached objects. An
  // absent pair is NOT necessarily allowed: inspect default permissions.
  bool effectivePermission(const moveit_msgs::msg::AllowedCollisionMatrix& acm,
                           const std::string& x,const std::string& y){
    const auto explicitValue=pairValue(acm,x,y);
    if(explicitValue.has_value())return *explicitValue;
    auto defaultOf=[&](const std::string& name)->std::optional<bool>{
      const auto it=std::find(acm.default_entry_names.begin(),acm.default_entry_names.end(),name);
      if(it==acm.default_entry_names.end())return std::nullopt;
      const auto k=static_cast<size_t>(it-acm.default_entry_names.begin());
      if(k>=acm.default_entry_values.size())throw std::runtime_error("Malformed ACM default entries");
      return acm.default_entry_values[k];
    };
    const auto dx=defaultOf(x),dy=defaultOf(y);
    // Conservative: if either default permits contact, don't call the
    // missing explicit pair a verified forbidden contact.
    return dx.value_or(false)||dy.value_or(false);
  }
  void setAcm(const std::string& x,const std::string& y,bool allow,bool restore){
    if(x.empty()||y.empty()||x==y)throw std::runtime_error("Invalid ACM pair");
    auto key=std::minmax(x,y);std::pair<std::string,std::string> pair{key.first,key.second};
    if(dry_)return;
    Lock guard(acmLock_);
    if(restore&&!saved_.count(pair))throw std::runtime_error("ACM restore without saved previous value: "+x+"/"+y);
    // Record the effective prior permission, not only an explicitly named pair.
    if(!restore&&!saved_.count(pair)){
      auto before=getAcm();saved_[pair]=effectivePermission(before,x,y);
    }
    const bool value=restore?saved_[pair].value_or(false):allow;
    std::string lastObserved="unread";
    // Each retry merges into the latest scene; don't replace other concurrent changes.
    for(int attempt=0;attempt<5;++attempt){
      auto acm=getAcm();
      const auto i=ensureAcmName(acm,x),j=ensureAcmName(acm,y);
      acm.entry_values[i].enabled[j]=value;acm.entry_values[j].enabled[i]=value;
      moveit_msgs::msg::PlanningScene diff;
      diff.is_diff=true;diff.robot_state.is_diff=true;diff.allowed_collision_matrix=acm;
      if(!scene_.applyPlanningScene(diff)){
        lastObserved="applyPlanningScene rejected update";
      }else{
        for(int poll=0;poll<5;++poll){
          const auto seen=getAcm();
          const auto explicitValue=pairValue(seen,x,y);
          const bool effective=effectivePermission(seen,x,y);
          lastObserved=explicitValue.has_value()?(*explicitValue?"explicit true":"explicit false"):
            (effective?"absent but default permits":"absent and default forbids");
          // An absent pair with no permissive default is a valid restored
          // false; it is NOT an acceptable way to confirm an allow=true.
          if(explicitValue==std::optional<bool>(value) || (!value&&!effective)){
            if(restore)saved_.erase(pair);
            return;
          }
          std::this_thread::sleep_for(100ms);
        }
      }
      std::this_thread::sleep_for(100ms);
    }
    throw std::runtime_error("ACM verification failed: "+x+"/"+y+
       " expected="+(value?"allow":"forbid")+" observed="+lastObserved);
  }
  void restoreOutstanding(){
    if(dry_){saved_.clear();return;}
    const auto previous=saved_;
    std::vector<std::string> failures;
    for(const auto& p:previous){
      try{setAcm(p.first.first,p.first.second,false,true);}
      catch(const std::exception& e){failures.push_back(e.what());
        RCLCPP_ERROR(n_->get_logger(),"[ACM CLEANUP] %s",e.what());}
    }
    if(!failures.empty())throw std::runtime_error(
      "ACM cleanup could not verify "+std::to_string(failures.size())+" pair(s); inspect log");
  }
  void cancelPendingGantry(){
    std::vector<std::string> toCancel;
    {
      std::lock_guard<std::mutex> lock(gantryMutex_);
      for(const auto& id:pendingGantry_) {
        const auto it=gantryResults_.find(id);
        if(it==gantryResults_.end() || (it->second.first!="DONE" && it->second.first!="ERROR"))
          toCancel.push_back(id);
      }
    }
    for(const auto& id:toCancel) {
      std_msgs::msg::String msg;msg.data=id;gantryCancel_->publish(msg);
      RCLCPP_WARN(n_->get_logger(),"[GANTRY] cancel requested id=%s",id.c_str());
    }
  }
  std::pair<std::string,std::string> waitGantryStatus(const std::string& id,double timeout,bool acceptanceOnly){
    if(timeout<=0||!std::isfinite(timeout))throw std::runtime_error("Invalid gantry timeout");
    std::unique_lock<std::mutex> lock(gantryMutex_);
    const auto deadline=std::chrono::steady_clock::now()+std::chrono::duration<double>(timeout);
    while(rclcpp::ok()) {
      const auto it=gantryResults_.find(id);
      if(it!=gantryResults_.end()) {
        if(it->second.first=="DONE"){
          pendingGantry_.erase(id);
          return it->second;
        }
        if(it->second.first=="ERROR" || it->second.first=="REJECTED"){
          pendingGantry_.erase(id);
          throw std::runtime_error("Gantry "+id+": "+it->second.first+": "+it->second.second);
        }
        if(acceptanceOnly && it->second.first=="RUNNING")return it->second;
      }
      if(gantryCv_.wait_until(lock,deadline)==std::cv_status::timeout)break;
    }
    throw std::runtime_error("Gantry "+id+" did not report "+(acceptanceOnly?"acceptance":"completion")+" within "+std::to_string(timeout)+"s");
  }
  void gantry(const YAML::Node& op){
    if(dry_)return;
    const std::string id=instance_+"__"+str(op,"request_id");
    if(id==instance_+"__")throw std::runtime_error("Gantry command needs request_id");
    const double x=num(op,"x",0),z=num(op,"z",0);
    const double speed=num(op,"velocity",0.4),acc=num(op,"acceleration",0.4);
    if(!std::isfinite(x)||!std::isfinite(z)||!std::isfinite(speed)||!std::isfinite(acc)||speed<=0||acc<=0)
      throw std::runtime_error("Invalid gantry target/speed/acceleration");
    auto start=std::chrono::steady_clock::now();
    while(gantryCmd_->get_subscription_count()==0){
      if(std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()>10)
        throw std::runtime_error("Gantry JTC topic subscriber unavailable");
      std::this_thread::sleep_for(100ms);
    }
    {
      std::lock_guard<std::mutex> lock(gantryMutex_);
      if(!pendingGantry_.insert(id).second)throw std::runtime_error("Duplicate gantry request id: "+id);
      gantryResults_.erase(id);
    }
    YAML::Emitter out;
    out << YAML::BeginMap << YAML::Key << "request_id" << YAML::Value << id
        << YAML::Key << "x" << YAML::Value << x << YAML::Key << "z" << YAML::Value << z
        << YAML::Key << "velocity" << YAML::Value << speed
        << YAML::Key << "acceleration" << YAML::Value << acc << YAML::EndMap;
    std_msgs::msg::String command;command.data=out.c_str();gantryCmd_->publish(command);
    RCLCPP_INFO(n_->get_logger(),"[GANTRY TOPIC] requested id=%s x=%.3f z=%.3f speed=%.3f acc=%.3f",
      id.c_str(),x,z,speed,acc);
    waitGantryStatus(id,20.0,true);
    if(flag(op,"wait",false))waitGantry(id,num(op,"timeout",120));
  }
  void waitGantry(const std::string& id,double timeout){
    if(dry_)return;
    const auto result=waitGantryStatus(id,timeout,false);
    RCLCPP_INFO(n_->get_logger(),"[GANTRY TOPIC] completed id=%s status=%s",id.c_str(),result.first.c_str());
  }
  void stepRun(const YAML::Node& op){
    if(op["enabled"]&&!op["enabled"].as<bool>())return;
    const auto id=str(op,"id",str(op,"op")),kind=str(op,"op");
    RCLCPP_INFO(n_->get_logger(),"[ACTION STEP] %s / %s",name_.c_str(),id.c_str());
    if(kind=="move"){
      if(op["before"])for(const auto& item:op["before"])stepRun(item);
      motion(op);
      if(op["after"])for(const auto& item:op["after"])stepRun(item);
    }else if(kind=="attach")attachObject(op);
    else if(kind=="detach")detachObject(op);
    else if(kind=="acm_allow"||kind=="acm_restore"){
      for(const auto& p:need(op,"pairs")){if(!p.IsSequence()||p.size()!=2)throw std::runtime_error("ACM pairs require [name,name]");
        setAcm(p[0].as<std::string>(),p[1].as<std::string>(),kind=="acm_allow",kind=="acm_restore");}
    }else if(kind=="gantry_send")gantry(op);
    else if(kind=="gantry_wait")waitGantry(instance_+"__"+str(op,"request_id"),num(op,"timeout",120));
    else if(kind=="sleep") {if(!dry_)std::this_thread::sleep_for(std::chrono::duration<double>(num(op,"seconds",0)));}
    else throw std::runtime_error("Unknown action step operation: "+kind);
  }
  rclcpp::Node::SharedPtr n_;tf2_ros::Buffer tf_;std::shared_ptr<tf2_ros::TransformListener> listener_;
  moveit::planning_interface::PlanningSceneInterface scene_;
  std::map<std::string,std::unique_ptr<MGI>> groups_;
  rclcpp::Client<moveit_msgs::srv::GetStateValidity>::SharedPtr validity_;
  rclcpp::Client<moveit_msgs::srv::GetPlanningScene>::SharedPtr getScene_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr gantryCmd_,gantryCancel_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr gantryStatus_;
  std::mutex gantryMutex_;std::condition_variable gantryCv_;
  std::map<std::string,std::pair<std::string,std::string>> gantryResults_;
  std::set<std::string> pendingGantry_;
  std::map<std::pair<std::string,std::string>,std::optional<bool>> saved_;
  std::map<std::string,std::string> robotGroup_,robotLink_,robotTyingLink_,robotToolMount_;
  YAML::Node params_,action_,workcell_;std::string name_,fullGroup_,acmLock_,instance_;bool dry_{true},sim_{false};
};

int main(int argc,char** argv){rclcpp::init(argc,argv);
  auto node=std::make_shared<rclcpp::Node>("sa3_action_engine");
  rclcpp::executors::MultiThreadedExecutor executor(rclcpp::ExecutorOptions(),4);
  executor.add_node(node);std::thread spin([&]{executor.spin();});int rc=1;
  try{ActionEngine app(node);rc=app.run();}catch(const std::exception& e){RCLCPP_ERROR(node->get_logger(),"ACTION INIT FAILED: %s",e.what());}
  executor.cancel();if(spin.joinable())spin.join();rclcpp::shutdown();return rc;
}